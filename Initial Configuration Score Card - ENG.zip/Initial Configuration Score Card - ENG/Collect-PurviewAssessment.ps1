#requires -Version 7.0

[CmdletBinding()]
param(
    [ValidateSet('Basic', 'Intermediate', 'Full')]
    [string]$Profile,

    [ValidateSet(30, 60, 90)]
    [int]$LookbackDays = 30,

    [string]$ScoreConfigPath,

    [string]$CollectedDataPath,

    [string]$ExportedDataPath,

    [switch]$InstallMissingModules,

    [switch]$SkipGraph,

    [switch]$SkipCompliance,

    [string[]]$OnlySources,

    [switch]$SkipExchangeOnlineConnection,

    [switch]$DeviceAuthentication,

    [switch]$DryRun
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:CollectorVersion = '1.1.0'
$script:RunItems = [System.Collections.Generic.List[object]]::new()
$script:RunMessages = [System.Collections.Generic.List[object]]::new()
$script:RunStartedUtc = [DateTime]::UtcNow
$script:ReportPath = $null
$script:OnlySources = @($OnlySources | ForEach-Object { $_ -split ',' } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })

function Select-CollectionProfile {
    Write-Host ''
    Write-Host 'Microsoft Purview Initial Configuration Score Card'
    Write-Host '1. Basic        - DLP, labels, licensing, and aggregated usage'
    Write-Host '2. Intermediate - Basic + IRM, retention, and Activity Explorer'
    Write-Host '3. Full         - Intermediate + Information Barriers, Communication Compliance, and cross-validation'
    Write-Host ''

    do {
        $selection = Read-Host 'Select 1, 2, or 3'
    } until ($selection -in @('1', '2', '3'))

    switch ($selection) {
        '1' { return 'Basic' }
        '2' { return 'Intermediate' }
        '3' { return 'Full' }
    }
}

function Get-ProfileRank {
    param([Parameter(Mandatory)][string]$Name)
    switch ($Name) {
        'Basic' { return 1 }
        'Intermediate' { return 2 }
        'Full' { return 3 }
        default { throw "Unknown profile: $Name" }
    }
}

function Assert-ScoreConfiguration {
    param([Parameter(Mandatory)]$Configuration)

    $dimensionWeight = [double](($Configuration.dimensions | Measure-Object -Property weight -Sum).Sum)
    $allMetrics = @($Configuration.dimensions | ForEach-Object { @($_.metrics) })
    $metricWeight = [double](($allMetrics | Measure-Object -Property weight -Sum).Sum)

    if ([Math]::Abs($dimensionWeight - 100) -gt 0.001) {
        throw "Dimension weights must total 100; current total is $dimensionWeight."
    }
    if ([Math]::Abs($metricWeight - 100) -gt 0.001) {
        throw "Metric weights must total 100; current total is $metricWeight."
    }

    $metricIds = @($allMetrics | ForEach-Object { [string]$_.id })
    $duplicateIds = @($metricIds | Group-Object | Where-Object Count -gt 1 | ForEach-Object Name)
    if ($duplicateIds.Count -gt 0) {
        throw ('Duplicate metric IDs: ' + ($duplicateIds -join ', '))
    }

    foreach ($dimension in $Configuration.dimensions) {
        $childWeight = [double](($dimension.metrics | Measure-Object -Property weight -Sum).Sum)
        if ([Math]::Abs($childWeight - [double]$dimension.weight) -gt 0.001) {
            throw "Metrics in dimension '$($dimension.id)' total $childWeight but dimension weight is $($dimension.weight)."
        }
    }

    $requiredOverrideFields = @($Configuration.manualOverrideRequirements.requiredFields)
    foreach ($property in $Configuration.manualOverrides.PSObject.Properties) {
        if ($null -eq $property.Value) { continue }
        $missingFields = @($requiredOverrideFields | Where-Object { -not $property.Value.PSObject.Properties[$_] })
        if ($missingFields.Count -gt 0) {
            throw "Manual override '$($property.Name)' is missing: $($missingFields -join ', ')."
        }
        $score = [double]$property.Value.score
        if ($score -lt [double]$Configuration.manualOverrideRequirements.scoreMinimum -or $score -gt [double]$Configuration.manualOverrideRequirements.scoreMaximum) {
            throw "Manual override '$($property.Name)' has an out-of-range score."
        }
    }
}

function Write-AtomicJson {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][AllowNull()]$InputObject
    )

    $directory = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $directory)) {
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
    }

    $temporaryPath = Join-Path $directory ('.{0}.{1}.tmp' -f ([IO.Path]::GetFileName($Path)), ([guid]::NewGuid().ToString('N')))
    try {
        $json = $InputObject | ConvertTo-Json -Depth 100
        Set-Content -LiteralPath $temporaryPath -Value $json -Encoding utf8NoBOM
        Move-Item -LiteralPath $temporaryPath -Destination $Path -Force
    }
    finally {
        if (Test-Path -LiteralPath $temporaryPath) {
            Remove-Item -LiteralPath $temporaryPath -Force
        }
    }
}

function Add-RunMessage {
    param(
        [Parameter(Mandatory)][ValidateSet('Information', 'Warning', 'Error')][string]$Level,
        [Parameter(Mandatory)][string]$Message
    )

    $script:RunMessages.Add([pscustomobject]@{
        timestampUtc = [DateTime]::UtcNow.ToString('o')
        level = $Level
        message = $Message
    })
}

function Save-Evidence {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Source,
        [Parameter(Mandatory)][string]$Command,
        [Parameter(Mandatory)][string]$Status,
        [AllowNull()]$Data,
        [string]$Message,
        [double]$DurationSeconds = 0
    )

    $recordCount = 0
    if ($null -ne $Data) { $recordCount = @($Data).Count }
    $safeName = $Name -replace '[^A-Za-z0-9_.-]', '_'
    $fileName = "$safeName.json"
    $path = Join-Path $script:RunPath $fileName

    $envelope = [ordered]@{
        schemaVersion = '1.0.0'
        collectorVersion = $script:CollectorVersion
        collectedAtUtc = [DateTime]::UtcNow.ToString('o')
        profile = $script:SelectedProfile
        lookbackDays = $LookbackDays
        source = $Source
        command = $Command
        evidenceStatus = $Status
        message = $Message
        recordCount = $recordCount
        data = $Data
    }

    Write-AtomicJson -Path $path -InputObject $envelope

    $script:RunItems.Add([pscustomobject]@{
        name = $Name
        source = $Source
        status = $Status
        recordCount = $recordCount
        durationSeconds = [Math]::Round($DurationSeconds, 3)
        file = $fileName
        message = $Message
    })
}

function Invoke-CollectionStep {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Source,
        [Parameter(Mandatory)][string]$Command,
        [Parameter(Mandatory)][scriptblock]$Action,
        [string[]]$RequiredCommands = @(),
        [bool]$Enabled = $true,
        [string]$DisabledStatus = 'Unavailable',
        [string]$DisabledReason = 'Source is unavailable.'
    )

    if ($script:OnlySources.Count -gt 0 -and $Name -notin $script:OnlySources) {
        return
    }

    if ($DryRun) {
        Save-Evidence -Name $Name -Source $Source -Command $Command -Status 'NotCollected' -Data $null -Message 'Planned by dry run; no remote connection was made.'
        return
    }

    if (-not $Enabled) {
        Save-Evidence -Name $Name -Source $Source -Command $Command -Status $DisabledStatus -Data $null -Message $DisabledReason
        return
    }

    $missingCommands = @($RequiredCommands | Where-Object { -not (Get-Command -Name $_ -ErrorAction SilentlyContinue) })
    if ($missingCommands.Count -gt 0) {
        Save-Evidence -Name $Name -Source $Source -Command $Command -Status 'Unavailable' -Data $null -Message ('Missing command(s): ' + ($missingCommands -join ', '))
        return
    }

    $stopwatch = [Diagnostics.Stopwatch]::StartNew()
    try {
        $result = @(& $Action)
        $stopwatch.Stop()
        $status = if ($result.Count -eq 0) { 'NotObserved' } else { 'Observed' }
        $message = if ($result.Count -eq 0) { 'The query completed successfully and returned no records.' } else { $null }
        Save-Evidence -Name $Name -Source $Source -Command $Command -Status $status -Data $result -Message $message -DurationSeconds $stopwatch.Elapsed.TotalSeconds
    }
    catch {
        $stopwatch.Stop()
        $detail = '{0}: {1}' -f $_.Exception.GetType().Name, $_.Exception.Message
        Save-Evidence -Name $Name -Source $Source -Command $Command -Status 'Unavailable' -Data $null -Message $detail -DurationSeconds $stopwatch.Elapsed.TotalSeconds
        Add-RunMessage -Level Warning -Message "$Name could not be collected. $detail"
    }
}

function Import-CollectorModule {
    param([Parameter(Mandatory)][string]$Name)

    if (-not (Get-Module -ListAvailable -Name $Name)) {
        if (-not $InstallMissingModules) {
            throw "Module '$Name' is not installed. Re-run with -InstallMissingModules or install it for CurrentUser."
        }

        Install-Module -Name $Name -Scope CurrentUser -Repository PSGallery -Force -AllowClobber
    }

    Import-Module -Name $Name -ErrorAction Stop
}

function Get-GraphReportPeriod {
    param([Parameter(Mandatory)][int]$Days)
    if ($Days -eq 30) { return 'D30' }
    return 'D90'
}

function ConvertTo-Int64Safe {
    param([AllowNull()]$Value)
    if ($null -eq $Value -or [string]::IsNullOrWhiteSpace([string]$Value)) { return [int64]0 }
    $number = [int64]0
    if ([int64]::TryParse(([string]$Value), [Globalization.NumberStyles]::Integer, [Globalization.CultureInfo]::InvariantCulture, [ref]$number)) {
        return $number
    }
    return [int64]0
}

function Get-GraphCsvAggregate {
    param(
        [Parameter(Mandatory)][string]$CommandName,
        [Parameter(Mandatory)][string]$ReportName,
        [Parameter(Mandatory)][string[]]$Columns
    )

    $period = Get-GraphReportPeriod -Days $LookbackDays
    $tempPath = Join-Path ([IO.Path]::GetTempPath()) ('purview-{0}.csv' -f ([guid]::NewGuid().ToString('N')))
    try {
        & $CommandName -Period $period -OutFile $tempPath | Out-Null
        $rows = @(Import-Csv -LiteralPath $tempPath)
        $cutoff = [DateTime]::UtcNow.Date.AddDays(-1 * ($LookbackDays - 1))

        if ($LookbackDays -eq 60) {
            $rows = @($rows | Where-Object {
                $reportDate = [DateTime]::MinValue
                [DateTime]::TryParse([string]$_.'Report Date', [ref]$reportDate) -and $reportDate.Date -ge $cutoff
            })
        }

        $totals = [ordered]@{}
        foreach ($column in $Columns) {
            $sum = [int64]0
            foreach ($row in $rows) {
                $sum += ConvertTo-Int64Safe -Value $row.$column
            }
            $totals[$column] = $sum
        }

        $daily = foreach ($row in $rows) {
            $entry = [ordered]@{
                reportDate = $row.'Report Date'
                reportPeriod = $row.'Report Period'
            }
            foreach ($column in $Columns) {
                $entry[$column] = ConvertTo-Int64Safe -Value $row.$column
            }
            [pscustomobject]$entry
        }

        [pscustomobject]@{
            reportName = $ReportName
            requestedLookbackDays = $LookbackDays
            graphPeriodRequested = $period
            filteredFromD90ForSixtyDays = ($LookbackDays -eq 60)
            cutoffDateUtc = $cutoff.ToString('yyyy-MM-dd')
            rowCount = $rows.Count
            totals = [pscustomobject]$totals
            daily = @($daily)
        }
    }
    finally {
        if (Test-Path -LiteralPath $tempPath) {
            Remove-Item -LiteralPath $tempPath -Force
        }
    }
}

function Get-DirectoryCoverageSummary {
    param([Parameter(Mandatory)]$ScoreConfiguration)

    $skus = @(Get-MgSubscribedSku -All)
    $users = @(Get-MgUser -All -Property Id,AccountEnabled,AssignedLicenses,AssignedPlans,UserType)

    $skuById = @{}
    foreach ($sku in $skus) {
        $skuById[[string]$sku.SkuId] = [string]$sku.SkuPartNumber
    }

    $activeMembers = @($users | Where-Object { $_.AccountEnabled -eq $true -and $_.UserType -eq 'Member' })
    $activeGuests = @($users | Where-Object { $_.AccountEnabled -eq $true -and $_.UserType -eq 'Guest' })
    $activeLicensedMembers = @($activeMembers | Where-Object { @($_.AssignedLicenses).Count -gt 0 })

    $assignmentCounts = @{}
    foreach ($user in $activeMembers) {
        foreach ($license in @($user.AssignedLicenses)) {
            $skuName = $skuById[[string]$license.SkuId]
            if ([string]::IsNullOrWhiteSpace($skuName)) { $skuName = [string]$license.SkuId }
            if (-not $assignmentCounts.ContainsKey($skuName)) { $assignmentCounts[$skuName] = 0 }
            $assignmentCounts[$skuName]++
        }
    }

    $eligibleSkuNames = @($ScoreConfiguration.collection.eligibleLicensing.skuPartNumbers)
    $eligiblePlanNames = @($ScoreConfiguration.collection.eligibleLicensing.servicePlanNames)
    $eligibleConfigured = ($eligibleSkuNames.Count + $eligiblePlanNames.Count) -gt 0
    $eligibleUserCount = $null

    if ($eligibleConfigured) {
        $eligibleSkuIds = @($skus | Where-Object { $_.SkuPartNumber -in $eligibleSkuNames } | ForEach-Object { [string]$_.SkuId })
        $eligibleUserCount = @($activeMembers | Where-Object {
            $user = $_
            $hasSku = @($user.AssignedLicenses | Where-Object { [string]$_.SkuId -in $eligibleSkuIds }).Count -gt 0
            $hasPlan = $false
            if ($eligiblePlanNames.Count -gt 0) {
                $hasPlan = @($user.AssignedPlans | Where-Object {
                    $planName = if ($_.PSObject.Properties['ServicePlanName']) { [string]$_.ServicePlanName } elseif ($_.PSObject.Properties['Service']) { [string]$_.Service } else { '' }
                    $planName -in $eligiblePlanNames -and $_.CapabilityStatus -eq 'Enabled'
                }).Count -gt 0
            }
            $hasSku -or $hasPlan
        }).Count
    }

    [pscustomobject]@{
        totalDirectoryUsers = $users.Count
        activeMemberUsers = $activeMembers.Count
        activeGuestUsers = $activeGuests.Count
        disabledUsers = @($users | Where-Object { $_.AccountEnabled -ne $true }).Count
        activeMemberUsersWithAnyLicense = $activeLicensedMembers.Count
        generalLicenseCoverageRatio = if ($activeMembers.Count -gt 0) { [Math]::Round($activeLicensedMembers.Count / $activeMembers.Count, 6) } else { $null }
        eligibleLicenseConfigurationPresent = $eligibleConfigured
        eligibleSkuPartNumbers = $eligibleSkuNames
        eligibleServicePlanNames = $eligiblePlanNames
        activeTargetUsersWithEligibleSkuOrPlan = $eligibleUserCount
        eligibleLicenseCoverageRatio = if ($eligibleConfigured -and $activeMembers.Count -gt 0) { [Math]::Round($eligibleUserCount / $activeMembers.Count, 6) } else { $null }
        eligibleLicenseEvidenceStatus = if ($eligibleConfigured) { 'Observed' } else { 'Unavailable' }
        eligibleLicenseMessage = if ($eligibleConfigured) { $null } else { 'Configure eligible SKU part numbers or service plan names in scoring-config.json.' }
        activeAssignmentsBySku = @($assignmentCounts.GetEnumerator() | Sort-Object Name | ForEach-Object {
            [pscustomobject]@{ skuPartNumber = $_.Name; activeAssignedUsers = $_.Value }
        })
    }
}

function Get-ActivityExplorerAggregate {
    param([Parameter(Mandatory)]$ActivityConfiguration)

    $windowDays = [Math]::Min([int]$ActivityConfiguration.maximumLookbackDays, $LookbackDays)
    $endTime = [DateTime]::UtcNow.AddMinutes(-5)
    $startTime = $endTime.AddDays(-1 * $windowDays).AddMinutes(10)
    $pageSize = [int]$ActivityConfiguration.pageSize
    $maximumPages = [int]$ActivityConfiguration.maximumPages

    $activityCounts = @{}
    $workloadCounts = @{}
    $labelCounts = @{}
    $policyCounts = @{}
    $distinctUsers = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    $totalRecords = 0
    $pages = 0
    $pageCookie = $null

    do {
        $parameters = @{
            StartTime = $startTime
            EndTime = $endTime
            OutputFormat = 'Json'
            PageSize = $pageSize
        }
        if (-not [string]::IsNullOrWhiteSpace([string]$pageCookie)) {
            $parameters.PageCookie = $pageCookie
        }

        $response = Export-ActivityExplorerData @parameters
        $pages++
        $records = @()
        if ($null -ne $response.ResultData) {
            if ($response.ResultData -is [string]) {
                $records = @($response.ResultData | ConvertFrom-Json)
            }
            else {
                $records = @($response.ResultData)
            }
        }

        foreach ($record in $records) {
            $totalRecords++
            $activity = [string]$record.Activity
            $workload = [string]$record.Workload
            $label = if ($record.PSObject.Properties['SensitivityLabel']) { [string]$record.SensitivityLabel } elseif ($record.PSObject.Properties['LabelName']) { [string]$record.LabelName } else { '' }
            $policy = if ($record.PSObject.Properties['PolicyName']) { [string]$record.PolicyName } else { '' }
            $user = if ($record.PSObject.Properties['UserId']) { [string]$record.UserId } elseif ($record.PSObject.Properties['User']) { [string]$record.User } else { '' }

            foreach ($pair in @(@($activityCounts, $activity), @($workloadCounts, $workload), @($labelCounts, $label), @($policyCounts, $policy))) {
                $table = $pair[0]
                $key = [string]$pair[1]
                if ([string]::IsNullOrWhiteSpace($key)) { continue }
                if (-not $table.ContainsKey($key)) { $table[$key] = 0 }
                $table[$key]++
            }
            if (-not [string]::IsNullOrWhiteSpace($user)) { [void]$distinctUsers.Add($user) }
        }

        $pageCookie = if ($response.PSObject.Properties['PageCookie']) { [string]$response.PageCookie } elseif ($response.PSObject.Properties['WaterMark']) { [string]$response.WaterMark } else { $null }
        $morePages = if ($response.PSObject.Properties['MorePagesAvailable']) { [bool]$response.MorePagesAvailable } else { -not [string]::IsNullOrWhiteSpace([string]$pageCookie) }
    } while ($morePages -and $pages -lt $maximumPages)

    $toRows = {
        param($Table, $KeyName)
        @($Table.GetEnumerator() | Sort-Object Value -Descending | ForEach-Object {
            $entry = [ordered]@{ count = $_.Value }
            $entry[$KeyName] = $_.Name
            [pscustomobject]$entry
        })
    }

    [pscustomobject]@{
        startTimeUtc = $startTime.ToString('o')
        endTimeUtc = $endTime.ToString('o')
        requestedLookbackDays = $LookbackDays
        effectiveLookbackDays = $windowDays
        totalRecords = $totalRecords
        pagesRead = $pages
        maximumPages = $maximumPages
        truncated = ($morePages -and $pages -ge $maximumPages)
        distinctUserCount = $distinctUsers.Count
        activityCounts = & $toRows $activityCounts 'activity'
        workloadCounts = & $toRows $workloadCounts 'workload'
        labelCounts = & $toRows $labelCounts 'label'
        policyCounts = & $toRows $policyCounts 'policy'
        detailedRecordsPersisted = $false
    }
}

function Get-AdvancedHuntingAggregate {
    param([Parameter(Mandatory)]$HuntingConfiguration)

    $queries = @($HuntingConfiguration.queries | Where-Object { $_.PSObject.Properties['enabled'] -and $_.enabled -eq $true })
    if ($queries.Count -eq 0) {
        throw 'Advanced Hunting is enabled but no enabled aggregate query is configured.'
    }

    foreach ($item in $queries) {
        $queryText = [string]$item.query
        if ($HuntingConfiguration.requireSummarizeOperator -and $queryText -notmatch '(?i)\bsummarize\b') {
            throw "Advanced Hunting query '$($item.name)' does not contain the required summarize operator."
        }

        $body = @{
            query = $queryText
            timespan = "P${LookbackDays}D"
        } | ConvertTo-Json -Depth 10

        $result = Invoke-MgGraphRequest -Method POST -Uri 'https://graph.microsoft.com/v1.0/security/runHuntingQuery' -Body $body -ContentType 'application/json'
        [pscustomobject]@{
            name = [string]$item.name
            timespan = "P${LookbackDays}D"
            query = $queryText
            schema = $result.schema
            results = $result.results
        }
    }
}

function Get-ContentExplorerAggregate {
    param([Parameter(Mandatory)]$ContentConfiguration)

    $tags = @($ContentConfiguration.tags)
    if ($tags.Count -eq 0) {
        throw 'Content Explorer is enabled but no tags are configured.'
    }

    foreach ($tag in $tags) {
        $workloads = if ($tag.PSObject.Properties['workloads'] -and @($tag.workloads).Count -gt 0) { @($tag.workloads) } else { @($ContentConfiguration.workloads) }
        foreach ($workload in $workloads) {
            try {
                $response = @(Export-ContentExplorerData -TagType $tag.tagType -TagName $tag.tagName -Workload $workload -PageSize ([int]$ContentConfiguration.pageSize))
                $first = $response | Select-Object -First 1
                [pscustomobject]@{
                    tagType = [string]$tag.tagType
                    tagName = [string]$tag.tagName
                    workload = [string]$workload
                    status = 'Observed'
                    totalCount = if ($null -ne $first -and $first.PSObject.Properties['TotalCount']) { $first.TotalCount } else { 0 }
                    morePagesAvailable = if ($null -ne $first -and $first.PSObject.Properties['MorePagesAvailable']) { $first.MorePagesAvailable } else { $null }
                    message = $null
                    detailedRecordsPersisted = $false
                }
            }
            catch {
                [pscustomobject]@{
                    tagType = [string]$tag.tagType
                    tagName = [string]$tag.tagName
                    workload = [string]$workload
                    status = 'Unavailable'
                    totalCount = $null
                    morePagesAvailable = $null
                    message = $_.Exception.Message
                    detailedRecordsPersisted = $false
                }
            }
        }
    }
}

if ([string]::IsNullOrWhiteSpace($Profile)) {
    $Profile = Select-CollectionProfile
}
$script:SelectedProfile = $Profile
$profileRank = Get-ProfileRank -Name $Profile

if ([string]::IsNullOrWhiteSpace($ScoreConfigPath)) {
    $ScoreConfigPath = Join-Path $PSScriptRoot 'scoring-config.json'
}
if ([string]::IsNullOrWhiteSpace($CollectedDataPath)) {
    $CollectedDataPath = Join-Path $PSScriptRoot 'Collected Data'
}
if ([string]::IsNullOrWhiteSpace($ExportedDataPath)) {
    $ExportedDataPath = Join-Path $PSScriptRoot 'Exported Data'
}

if (-not (Test-Path -LiteralPath $ScoreConfigPath -PathType Leaf)) {
    throw "Scoring configuration not found: $ScoreConfigPath"
}

$scoreConfiguration = Get-Content -LiteralPath $ScoreConfigPath -Raw | ConvertFrom-Json -Depth 100
Assert-ScoreConfiguration -Configuration $scoreConfiguration
if ($LookbackDays -notin @($scoreConfiguration.collection.allowedLookbackDays)) {
    throw "LookbackDays $LookbackDays is not allowed by the scoring configuration."
}

$runId = '{0}_{1}_{2}' -f ([DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ')), $Profile, ([guid]::NewGuid().ToString('N').Substring(0, 8))
$script:RunPath = Join-Path $CollectedDataPath $runId
New-Item -ItemType Directory -Path $script:RunPath -Force | Out-Null
Write-AtomicJson -Path (Join-Path $script:RunPath 'Score-Configuration.json') -InputObject $scoreConfiguration
$scoreConfigHash = (Get-FileHash -LiteralPath $ScoreConfigPath -Algorithm SHA256).Hash

$complianceReady = $false
$exchangeReady = $false
$graphReady = $false
$complianceReason = if ($SkipCompliance) { 'Skipped by -SkipCompliance.' } else { 'Compliance connection was not established.' }
$exchangeReason = if ($SkipCompliance) { 'Skipped by -SkipCompliance.' } else { 'Exchange Online connection was not established.' }
$graphReason = if ($SkipGraph) { 'Skipped by -SkipGraph.' } else { 'Microsoft Graph connection was not established.' }

try {
    if (-not $DryRun) {
        if (-not $SkipCompliance) {
            try {
                Import-CollectorModule -Name 'ExchangeOnlineManagement'
            }
            catch {
                $complianceReason = $_.Exception.Message
                Add-RunMessage -Level Warning -Message "Exchange Online module import failed: $complianceReason"
            }

            if (Get-Module -Name 'ExchangeOnlineManagement') {
                if ($profileRank -ge 2 -and -not $SkipExchangeOnlineConnection) {
                    try {
                        $exchangeConnectParameters = @{ ShowBanner = $false }
                        if ($DeviceAuthentication) { $exchangeConnectParameters.DisableWAM = $true }
                        Connect-ExchangeOnline @exchangeConnectParameters
                        $exchangeReady = $true
                    }
                    catch {
                        $exchangeReason = $_.Exception.Message
                        Add-RunMessage -Level Warning -Message "Exchange Online connection failed; IRM sources will be unavailable: $exchangeReason"
                    }
                }

                try {
                    $complianceConnectParameters = @{ ShowBanner = $false }
                    if ($DeviceAuthentication) { $complianceConnectParameters.DisableWAM = $true }
                    Connect-IPPSSession @complianceConnectParameters
                    $complianceReady = $true
                    Add-RunMessage -Level Information -Message 'Connected to Security & Compliance PowerShell.'
                }
                catch {
                    $complianceReason = $_.Exception.Message
                    Add-RunMessage -Level Warning -Message "Compliance connection failed: $complianceReason"
                }
            }
        }

        if (-not $SkipGraph) {
            try {
                foreach ($module in @('Microsoft.Graph.Authentication', 'Microsoft.Graph.Users', 'Microsoft.Graph.Identity.DirectoryManagement', 'Microsoft.Graph.Reports')) {
                    Import-CollectorModule -Name $module
                }

                $graphScopes = [Collections.Generic.List[string]]::new()
                foreach ($scope in @('Organization.Read.All', 'LicenseAssignment.Read.All', 'User.Read.All', 'Reports.Read.All')) { $graphScopes.Add($scope) }
                if ($profileRank -ge 3 -and $scoreConfiguration.collection.advancedHunting.enabled -and ($script:OnlySources.Count -eq 0 -or 'AdvancedHuntingAggregate' -in $script:OnlySources)) {
                    $graphScopes.Add('ThreatHunting.Read.All')
                }
                $graphConnectParameters = @{
                    Scopes = @($graphScopes)
                    ContextScope = 'Process'
                    NoWelcome = $true
                }
                if ($DeviceAuthentication) { $graphConnectParameters.UseDeviceCode = $true }
                Connect-MgGraph @graphConnectParameters
                $graphReady = $true
                Add-RunMessage -Level Information -Message 'Connected to Microsoft Graph.'
            }
            catch {
                $graphReason = $_.Exception.Message
                Add-RunMessage -Level Warning -Message "Microsoft Graph connection failed: $graphReason"
            }
        }
    }

    $complianceDisabledStatus = if ($SkipCompliance) { 'NotCollected' } else { 'Unavailable' }
    $graphDisabledStatus = if ($SkipGraph) { 'NotCollected' } else { 'Unavailable' }

    Invoke-CollectionStep -Name 'DLPPolicies' -Source 'Microsoft Purview DLP' -Command 'Get-DlpCompliancePolicy' -RequiredCommands 'Get-DlpCompliancePolicy' -Enabled $complianceReady -DisabledStatus $complianceDisabledStatus -DisabledReason $complianceReason -Action {
        Get-DlpCompliancePolicy | Select-Object Name, Guid, Enabled, Mode, Workload, ExchangeLocation, SharePointLocation, OneDriveLocation, TeamsLocation, EndpointDlpLocation, Priority, DistributionStatus, WhenCreatedUTC, WhenChangedUTC, CreatedBy, LastModifiedBy, Comment
    }

    Invoke-CollectionStep -Name 'DLPRules' -Source 'Microsoft Purview DLP' -Command 'Get-DlpComplianceRule' -RequiredCommands 'Get-DlpComplianceRule' -Enabled $complianceReady -DisabledStatus $complianceDisabledStatus -DisabledReason $complianceReason -Action {
        Get-DlpComplianceRule | Select-Object Name, Guid, Policy, Disabled, Mode, Priority, Workload, ContentContainsSensitiveInformation, ContentContainsLabel, BlockAccess, BlockAccessScope, NotifyUser, NotifyPolicyTipCustomText, GenerateAlert, GenerateIncidentReport, IncidentReportContent, ReportSeverityLevel, AccessScope, WhenCreatedUTC, WhenChangedUTC
    }

    Invoke-CollectionStep -Name 'SensitivityLabels' -Source 'Microsoft Purview Information Protection' -Command 'Get-Label' -RequiredCommands 'Get-Label' -Enabled $complianceReady -DisabledStatus $complianceDisabledStatus -DisabledReason $complianceReason -Action {
        Get-Label | Select-Object DisplayName, Name, Guid, ParentLabelDisplayName, ParentId, IsParent, IsLabelGroup, Tooltip, DefaultContentLabel, ContentType, LocaleSettings, SchematizedDataCondition, ColumnAssetCondition, LabelActions, Settings, Priority, Workload, Policy, CreatedBy, LastModifiedBy, WhenChangedUTC, WhenCreatedUTC, Comment, Conditions
    }

    Invoke-CollectionStep -Name 'LabelPolicies' -Source 'Microsoft Purview Information Protection' -Command 'Get-LabelPolicy' -RequiredCommands 'Get-LabelPolicy' -Enabled $complianceReady -DisabledStatus $complianceDisabledStatus -DisabledReason $complianceReason -Action {
        Get-LabelPolicy | Select-Object Name, Guid, WhenChangedUTC, WhenCreatedUTC, Enabled, Mode, DistributionStatus, Type, Settings, Labels, ScopedLabels, PolicySettingsBlob, Workload, CreatedBy, LastModifiedBy, ExchangeLocation, ModernGroupLocation
    }

    Invoke-CollectionStep -Name 'Organization' -Source 'Microsoft Graph' -Command 'Get-MgOrganization' -RequiredCommands 'Get-MgOrganization' -Enabled $graphReady -DisabledStatus $graphDisabledStatus -DisabledReason $graphReason -Action {
        Get-MgOrganization -Property Id,DisplayName,CreatedDateTime,VerifiedDomains | Select-Object Id, DisplayName, CreatedDateTime, VerifiedDomains
    }

    Invoke-CollectionStep -Name 'SubscribedSkus' -Source 'Microsoft Graph' -Command 'Get-MgSubscribedSku' -RequiredCommands 'Get-MgSubscribedSku' -Enabled $graphReady -DisabledStatus $graphDisabledStatus -DisabledReason $graphReason -Action {
        Get-MgSubscribedSku -All | Select-Object SkuId, SkuPartNumber, AppliesTo, CapabilityStatus, ConsumedUnits, PrepaidUnits, ServicePlans
    }

    Invoke-CollectionStep -Name 'DirectoryCoverage' -Source 'Microsoft Graph' -Command 'Get-MgUser; Get-MgSubscribedSku (aggregate only)' -RequiredCommands @('Get-MgUser', 'Get-MgSubscribedSku') -Enabled $graphReady -DisabledStatus $graphDisabledStatus -DisabledReason $graphReason -Action {
        Get-DirectoryCoverageSummary -ScoreConfiguration $scoreConfiguration
    }

    Invoke-CollectionStep -Name 'EmailActivityCounts' -Source 'Microsoft Graph Reports' -Command 'Get-MgReportEmailActivityCount' -RequiredCommands 'Get-MgReportEmailActivityCount' -Enabled $graphReady -DisabledStatus $graphDisabledStatus -DisabledReason $graphReason -Action {
        Get-GraphCsvAggregate -CommandName 'Get-MgReportEmailActivityCount' -ReportName 'Email activity counts' -Columns @('Send', 'Receive', 'Read', 'Meeting Created', 'Meeting Interacted')
    }

    Invoke-CollectionStep -Name 'OneDriveFileCounts' -Source 'Microsoft Graph Reports' -Command 'Get-MgReportOneDriveUsageFileCount' -RequiredCommands 'Get-MgReportOneDriveUsageFileCount' -Enabled $graphReady -DisabledStatus $graphDisabledStatus -DisabledReason $graphReason -Action {
        Get-GraphCsvAggregate -CommandName 'Get-MgReportOneDriveUsageFileCount' -ReportName 'OneDrive usage file counts' -Columns @('Total', 'Active')
    }

    Invoke-CollectionStep -Name 'SharePointFileCounts' -Source 'Microsoft Graph Reports' -Command 'Get-MgReportSharePointSiteUsageFileCount' -RequiredCommands 'Get-MgReportSharePointSiteUsageFileCount' -Enabled $graphReady -DisabledStatus $graphDisabledStatus -DisabledReason $graphReason -Action {
        Get-GraphCsvAggregate -CommandName 'Get-MgReportSharePointSiteUsageFileCount' -ReportName 'SharePoint site usage file counts' -Columns @('Total', 'Active')
    }

    if ($profileRank -ge 2) {
        Invoke-CollectionStep -Name 'IRMConfiguration' -Source 'Exchange Online' -Command 'Get-IRMConfiguration' -RequiredCommands 'Get-IRMConfiguration' -Enabled $exchangeReady -DisabledStatus $complianceDisabledStatus -DisabledReason $exchangeReason -Action {
            Get-IRMConfiguration | Select-Object InternalLicensingEnabled, ExternalLicensingEnabled, AzureRMSLicensingEnabled, SimplifiedClientAccessEnabled, ClientAccessServerEnabled, SearchEnabled, JournalReportDecryptionEnabled, TransportDecryptionSetting, EDiscoverySuperUserEnabled, LicensingLocation
        }

        Invoke-CollectionStep -Name 'RMSTrustedPublishingDomains' -Source 'Exchange Online' -Command 'Get-RMSTrustedPublishingDomain' -RequiredCommands 'Get-RMSTrustedPublishingDomain' -Enabled $exchangeReady -DisabledStatus $complianceDisabledStatus -DisabledReason $exchangeReason -Action {
            Get-RMSTrustedPublishingDomain | Select-Object Name, Default, Status, KeyId, ExtranetLicensingUrl, IntranetLicensingUrl, LicensingLocation
        }

        Invoke-CollectionStep -Name 'RMSTemplates' -Source 'Exchange Online' -Command 'Get-RMSTemplate' -RequiredCommands 'Get-RMSTemplate' -Enabled $exchangeReady -DisabledStatus $complianceDisabledStatus -DisabledReason $exchangeReason -Action {
            Get-RMSTemplate | Select-Object Name, Id, Guid, Description, Type, Status, DistributionPoint, Archive, WhenChangedUTC
        }

        Invoke-CollectionStep -Name 'IRMTransportRules' -Source 'Exchange Online' -Command 'Get-TransportRule (IRM/OME actions only)' -RequiredCommands 'Get-TransportRule' -Enabled $exchangeReady -DisabledStatus $complianceDisabledStatus -DisabledReason $exchangeReason -Action {
            Get-TransportRule | Where-Object {
                $rule = $_
                ($rule.PSObject.Properties['ApplyRightsProtectionTemplate'] -and $null -ne $rule.ApplyRightsProtectionTemplate) -or
                ($rule.PSObject.Properties['ApplyOME'] -and [bool]$rule.ApplyOME) -or
                ($rule.PSObject.Properties['RemoveOME'] -and [bool]$rule.RemoveOME)
            } | Select-Object Name, Guid, State, Mode, Priority, ApplyRightsProtectionTemplate, ApplyOME, RemoveOME, FromScope, SentToScope, ExceptIfFromScope, ExceptIfSentToScope, Comments, WhenChangedUTC
        }

        Invoke-CollectionStep -Name 'RetentionLabels' -Source 'Microsoft Purview Data Lifecycle Management' -Command 'Get-ComplianceTag' -RequiredCommands 'Get-ComplianceTag' -Enabled $complianceReady -DisabledStatus $complianceDisabledStatus -DisabledReason $complianceReason -Action {
            Get-ComplianceTag | Select-Object Name, Guid, RetentionAction, RetentionDuration, RetentionType, IsRecordLabel, IsRegulatoryLabel, BehaviorDuringRetentionPeriod, ActionAfterRetentionPeriod, Workload, WhenCreatedUTC, WhenChangedUTC
        }

        Invoke-CollectionStep -Name 'RetentionPolicies' -Source 'Microsoft Purview Data Lifecycle Management' -Command 'Get-RetentionCompliancePolicy' -RequiredCommands 'Get-RetentionCompliancePolicy' -Enabled $complianceReady -DisabledStatus $complianceDisabledStatus -DisabledReason $complianceReason -Action {
            Get-RetentionCompliancePolicy | Select-Object Name, Guid, Enabled, Mode, Workload, ExchangeLocation, SharePointLocation, OneDriveLocation, ModernGroupLocation, TeamsChatLocation, TeamsChannelLocation, WhenCreatedUTC, WhenChangedUTC, DistributionStatus
        }

        Invoke-CollectionStep -Name 'RetentionRules' -Source 'Microsoft Purview Data Lifecycle Management' -Command 'Get-RetentionComplianceRule' -RequiredCommands 'Get-RetentionComplianceRule' -Enabled $complianceReady -DisabledStatus $complianceDisabledStatus -DisabledReason $complianceReason -Action {
            Get-RetentionComplianceRule | Select-Object Name, Guid, Policy, Disabled, RetentionDuration, RetentionComplianceAction, ExpirationDateOption, ContentMatchQuery, ApplyComplianceTag, WhenCreatedUTC, WhenChangedUTC
        }

        Invoke-CollectionStep -Name 'SensitiveInformationTypes' -Source 'Microsoft Purview Data Classification' -Command 'Get-DlpSensitiveInformationType' -RequiredCommands 'Get-DlpSensitiveInformationType' -Enabled $complianceReady -DisabledStatus $complianceDisabledStatus -DisabledReason $complianceReason -Action {
            Get-DlpSensitiveInformationType | Select-Object Name, Id, Publisher, ClassificationRuleCollectionId, Description, RecommendedConfidence
        }

        $activityEnabled = $complianceReady -and [bool]$scoreConfiguration.collection.activityExplorer.enabled
        $activityReason = if (-not $scoreConfiguration.collection.activityExplorer.enabled) { 'Disabled in scoring-config.json.' } else { $complianceReason }
        $activityStatus = if (-not $scoreConfiguration.collection.activityExplorer.enabled) { 'NotCollected' } else { $complianceDisabledStatus }
        Invoke-CollectionStep -Name 'ActivityExplorerAggregate' -Source 'Microsoft Purview Activity Explorer' -Command 'Export-ActivityExplorerData (aggregated in memory)' -RequiredCommands 'Export-ActivityExplorerData' -Enabled $activityEnabled -DisabledStatus $activityStatus -DisabledReason $activityReason -Action {
            Get-ActivityExplorerAggregate -ActivityConfiguration $scoreConfiguration.collection.activityExplorer
        }
    }

    if ($profileRank -ge 3) {
        Invoke-CollectionStep -Name 'InformationBarrierSegments' -Source 'Microsoft Purview Information Barriers' -Command 'Get-OrganizationSegment' -RequiredCommands 'Get-OrganizationSegment' -Enabled $complianceReady -DisabledStatus $complianceDisabledStatus -DisabledReason $complianceReason -Action {
            Get-OrganizationSegment | Select-Object Name, Guid, UserGroupFilter, CreatedBy, LastModifiedBy, WhenCreatedUTC, WhenChangedUTC
        }

        Invoke-CollectionStep -Name 'InformationBarrierPolicies' -Source 'Microsoft Purview Information Barriers' -Command 'Get-InformationBarrierPolicy' -RequiredCommands 'Get-InformationBarrierPolicy' -Enabled $complianceReady -DisabledStatus $complianceDisabledStatus -DisabledReason $complianceReason -Action {
            Get-InformationBarrierPolicy | Select-Object Name, Guid, State, AssignedSegment, SegmentsAllowed, SegmentsBlocked, WhenCreatedUTC, WhenChangedUTC
        }

        Invoke-CollectionStep -Name 'CommunicationCompliancePolicies' -Source 'Microsoft Purview Communication Compliance' -Command 'Get-SupervisoryReviewPolicyV2' -RequiredCommands 'Get-SupervisoryReviewPolicyV2' -Enabled $complianceReady -DisabledStatus $complianceDisabledStatus -DisabledReason $complianceReason -Action {
            Get-SupervisoryReviewPolicyV2 | Select-Object Name, Guid, Enabled, Workload, PolicyType, Reviewers, WhenCreatedUTC, WhenChangedUTC
        }

        $huntingConfigured = [bool]$scoreConfiguration.collection.advancedHunting.enabled
        Invoke-CollectionStep -Name 'AdvancedHuntingAggregate' -Source 'Microsoft Graph Security' -Command 'POST /security/runHuntingQuery' -RequiredCommands 'Invoke-MgGraphRequest' -Enabled ($graphReady -and $huntingConfigured) -DisabledStatus $(if ($huntingConfigured) { $graphDisabledStatus } else { 'NotCollected' }) -DisabledReason $(if ($huntingConfigured) { $graphReason } else { 'Disabled in scoring-config.json; configure reviewed aggregate queries first.' }) -Action {
            Get-AdvancedHuntingAggregate -HuntingConfiguration $scoreConfiguration.collection.advancedHunting
        }

        $contentConfigured = [bool]$scoreConfiguration.collection.contentExplorer.enabled
        Invoke-CollectionStep -Name 'ContentExplorerAggregate' -Source 'Microsoft Purview Content Explorer' -Command 'Export-ContentExplorerData (counts only)' -RequiredCommands 'Export-ContentExplorerData' -Enabled ($complianceReady -and $contentConfigured) -DisabledStatus $(if ($contentConfigured) { $complianceDisabledStatus } else { 'NotCollected' }) -DisabledReason $(if ($contentConfigured) { $complianceReason } else { 'Disabled in scoring-config.json; configure tag names first.' }) -Action {
            Get-ContentExplorerAggregate -ContentConfiguration $scoreConfiguration.collection.contentExplorer
        }
    }
}
finally {
    if (-not $DryRun) {
        if ($graphReady -and (Get-Command -Name Disconnect-MgGraph -ErrorAction SilentlyContinue)) {
            try { Disconnect-MgGraph | Out-Null } catch { Add-RunMessage -Level Warning -Message "Graph disconnect warning: $($_.Exception.Message)" }
        }
        if (($complianceReady -or $exchangeReady) -and (Get-Command -Name Disconnect-ExchangeOnline -ErrorAction SilentlyContinue)) {
            try { Disconnect-ExchangeOnline -Confirm:$false } catch { Add-RunMessage -Level Warning -Message "Exchange disconnect warning: $($_.Exception.Message)" }
        }
    }

    $runEndedUtc = [DateTime]::UtcNow
    $manifest = [ordered]@{
        schemaVersion = '1.0.0'
        collectorVersion = $script:CollectorVersion
        runId = $runId
        profile = $Profile
        lookbackDays = $LookbackDays
        dryRun = [bool]$DryRun
        deviceAuthentication = [bool]$DeviceAuthentication
        onlySources = @($script:OnlySources)
        skipExchangeOnlineConnection = [bool]$SkipExchangeOnlineConnection
        startedAtUtc = $script:RunStartedUtc.ToString('o')
        endedAtUtc = $runEndedUtc.ToString('o')
        durationSeconds = [Math]::Round(($runEndedUtc - $script:RunStartedUtc).TotalSeconds, 3)
        scoreConfiguration = [ordered]@{
            sourcePath = (Resolve-Path -LiteralPath $ScoreConfigPath).Path
            snapshotFile = 'Score-Configuration.json'
            sha256 = $scoreConfigHash
            modelVersion = [string]$scoreConfiguration.model.version
        }
        privacy = [ordered]@{
            aggregateFirst = $true
            detailedActivityExplorerRecordsPersisted = $false
            directoryUsersPersisted = $false
        }
        connections = [ordered]@{
            complianceReady = $complianceReady
            exchangeOnlineReady = $exchangeReady
            graphReady = $graphReady
        }
        summary = [ordered]@{
            sourceCount = $script:RunItems.Count
            observed = @($script:RunItems | Where-Object { $_.status -eq 'Observed' }).Count
            notObserved = @($script:RunItems | Where-Object { $_.status -eq 'NotObserved' }).Count
            unavailable = @($script:RunItems | Where-Object { $_.status -eq 'Unavailable' }).Count
            notCollected = @($script:RunItems | Where-Object { $_.status -eq 'NotCollected' }).Count
        }
        evidence = @($script:RunItems)
        messages = @($script:RunMessages)
    }
    Write-AtomicJson -Path (Join-Path $script:RunPath 'Run-Manifest.json') -InputObject $manifest

    $reportGeneratorPath = Join-Path $PSScriptRoot 'Export-PurviewHtmlReport.ps1'
    try {
        if (-not (Test-Path -LiteralPath $reportGeneratorPath -PathType Leaf)) {
            throw "HTML report generator not found: $reportGeneratorPath"
        }
        $script:ReportPath = @(& $reportGeneratorPath -RunPath $script:RunPath -ExportedDataPath $ExportedDataPath) | Select-Object -Last 1
        $manifest['report'] = [ordered]@{
            status = 'Created'
            path = $script:ReportPath
            latestPath = (Join-Path $ExportedDataPath $(if ($DryRun) { 'Purview-Assessment-Latest-DryRun.html' } else { 'Purview-Assessment-Latest.html' }))
        }
    }
    catch {
        Add-RunMessage -Level Warning -Message "HTML report generation failed: $($_.Exception.Message)"
        $manifest['report'] = [ordered]@{
            status = 'Failed'
            message = $_.Exception.Message
        }
    }
    $manifest['messages'] = @($script:RunMessages)
    Write-AtomicJson -Path (Join-Path $script:RunPath 'Run-Manifest.json') -InputObject $manifest
}

Write-Host ''
Write-Host "Collection completed: $script:RunPath"
Write-Host 'Review Run-Manifest.json before using the evidence for scoring.'
if ($script:ReportPath) { Write-Host "HTML report: $script:ReportPath" }
