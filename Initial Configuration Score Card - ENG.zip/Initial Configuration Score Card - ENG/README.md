# Purview Initial Configuration Score Card

Assessment and collection baseline for measuring the Microsoft Purview posture with evidence of configuration, coverage, adoption, and operations.

## Contents

- `SCORING-METHODOLOGY.md`: criteria, formulas, dimensions, standards mapping, and interpretation rules.
- `Principle of least Privileges.md`: minimum permissions by profile, Microsoft Graph scopes, and Entra, Purview, Exchange, and Defender roles.
- `scoring-config.json`: weights, thresholds, profiles, eligible licenses, optional sources, and manual overrides.
- `scoring-config.schema.json`: basic structural validation for the configuration.
- `Collect-PurviewAssessment.ps1`: interactive and parameter-driven collector.
- `Export-PurviewHtmlReport.ps1`: creates a self-contained HTML report from a collection run.
- `Merge-PurviewEvidence.ps1`: merges targeted retries while preserving evidence provenance and status.
- `Source Script Collectors`: original collector scripts retained as reference; they were not modified.
- `Collected Data`: one JSON folder per run, created automatically.
- `Exported Data`: versioned HTML reports and a `Latest` copy, created automatically.

## Scope of this release

This release defines the model and collects the evidence used by the Score Card. It does not present a final score when there are not enough observed values. This prevents unavailable sources from being treated as false zeroes.

The model keeps two separate results:

- `Posture Score`: maturity of observed controls, from 0 to 100.
- `Evidence Confidence`: proportion of the model supported by valid evidence, from 0 to 100.

## Requirements

- PowerShell 7 or later.
- An account with the appropriate read-only roles for the capabilities being collected.
- Modules:
  - `ExchangeOnlineManagement`
  - `Microsoft.Graph.Authentication`
  - `Microsoft.Graph.Users`
  - `Microsoft.Graph.Identity.DirectoryManagement`
  - `Microsoft.Graph.Reports`

The script does not install modules unless `-InstallMissingModules` is specified.

Baseline Microsoft Graph delegated permissions:

- `Organization.Read.All`
- `LicenseAssignment.Read.All`
- `User.Read.All`
- `Reports.Read.All`

When Advanced Hunting is enabled in the Full profile, `ThreatHunting.Read.All` is also requested. Final permissions and licensing must be validated against the tenant role model and the principle of least privilege.

## Running the collector

Interactive menu:

```powershell
pwsh -NoProfile -File ".\Collect-PurviewAssessment.ps1"
```

30-day baseline:

```powershell
pwsh -NoProfile -File ".\Collect-PurviewAssessment.ps1" -Profile Basic -LookbackDays 30
```

60-day Intermediate assessment:

```powershell
pwsh -NoProfile -File ".\Collect-PurviewAssessment.ps1" -Profile Intermediate -LookbackDays 60
```

90-day Full assessment, installing missing modules for the current user:

```powershell
pwsh -NoProfile -File ".\Collect-PurviewAssessment.ps1" -Profile Full -LookbackDays 90 -InstallMissingModules
```

Validate the execution plan without signing in:

```powershell
pwsh -NoProfile -File ".\Collect-PurviewAssessment.ps1" -Profile Full -LookbackDays 90 -DryRun
```

If the WAM flow does not display a sign-in window, use:

```powershell
pwsh -NoProfile -File ".\Collect-PurviewAssessment.ps1" -Profile Basic -LookbackDays 30 -DeviceAuthentication
```

Microsoft Graph displays a device code. For Exchange/Purview, the parameter disables WAM and uses the alternative interactive flow supported by the module.

Intentionally exclude a source:

```powershell
pwsh -NoProfile -File ".\Collect-PurviewAssessment.ps1" -Profile Basic -SkipGraph
```

An intentional exclusion is recorded as `NotCollected`; a module, permission, licensing, or connection failure is recorded as `Unavailable`.

## Collection profiles

### Basic

- DLP policies and rules.
- Sensitivity labels and publishing policies.
- Organization, SKUs, and aggregated user/license summary.
- Aggregated email, OneDrive, and SharePoint counts.

### Intermediate

Includes Basic and adds:

- IRM, trusted RMS publishing domains, and RMS templates.
- Mail flow rules that apply or remove IRM/OME protection.
- Retention labels, policies, and rules.
- Sensitive information type inventory.
- Activity Explorer data aggregated in memory, without persisting user-level records.

### Full

Includes Intermediate and adds:

- Information Barriers segments and policies.
- Communication Compliance policies.
- Configurable, aggregated Advanced Hunting.
- Content Explorer counts by configured label and workload.

## Configuration required before scoring

### Eligible licensing

In `scoring-config.json`, complete one or both arrays:

```json
"eligibleLicensing": {
  "targetPopulation": "activeMemberUsers",
  "skuPartNumbers": ["ENTERPRISEPREMIUM"],
  "servicePlanNames": [],
  "emptyConfigurationBehavior": "Unavailable"
}
```

The configured SKU must reflect the contracts, add-ons, and capabilities actually being assessed. The current configuration uses `Microsoft_365_E5_(no_Teams)`, observed in the tenant. If both arrays remain empty, `COV-02` remains `Unavailable`.

### Advanced Hunting

Advanced Hunting is enabled for the Full profile with an aggregated `CloudAppEvents` query grouped by action type. Every additional query must be reviewed and end in aggregation:

```json
"advancedHunting": {
  "enabled": true,
  "requireSummarizeOperator": true,
  "queries": [
    {
      "name": "Reviewed aggregate query",
      "enabled": true,
      "query": "<available table> | where Timestamp > ago(30d) | summarize EventCount=count() by bin(Timestamp, 1d)"
    }
  ]
}
```

The availability of `CloudAppEvents` depends on tenant licensing, retention, and permissions. The collector rejects queries without `summarize` while the safeguard is enabled.

### Content Explorer

Content Explorer is enabled with the sensitivity labels observed in the Basic run. Review the list whenever the tenant taxonomy changes:

```json
"contentExplorer": {
  "enabled": true,
  "pageSize": 1,
  "workloads": ["EXO", "ODB", "SPO", "Teams"],
  "tags": [
    {
      "tagType": "Sensitivity",
      "tagName": "Confidential",
      "workloads": ["EXO", "ODB", "SPO"]
    }
  ]
}
```

The query stores only counts and pagination metadata, not the matched items.

### Manual overrides

Every valid override must contain:

```json
"MON-05": {
  "score": 3,
  "reason": "Formal quarterly review completed.",
  "evidence": "GRC-2026-Q3 minutes",
  "approvedBy": "DPO",
  "approvedOn": "2026-08-27",
  "expiresOn": "2026-11-30"
}
```

Observed evidence must not be replaced with a manual opinion unless the rationale is recorded.

## Outputs

Each execution creates:

```text
Collected Data/
  20260827T120000Z_Basic_a1b2c3d4/
    Score-Configuration.json
    Run-Manifest.json
    DLPPolicies.json
    DLPRules.json
    ...
```

`Run-Manifest.json` records each source status, duration, count, controlled errors, version, and the SHA-256 hash of the scoring configuration used.

Files use atomic replacement and `ConvertTo-Json -Depth 100`; the workflow does not use `Add-Content` or Log Analytics.

At completion, the collector also creates:

```text
Exported Data/
  Purview-Assessment-<RunId>.html
  Purview-Assessment-Latest.html
  Purview-Assessment-Latest-DryRun.html
```

`-DryRun` executions never replace the `Latest` report from a real collection.

To regenerate the HTML for an existing run:

```powershell
pwsh -NoProfile -File ".\Export-PurviewHtmlReport.ps1" `
  -RunPath ".\Collected Data\<RunId>" `
  -ExportedDataPath ".\Exported Data"
```

## Time-window considerations

- Graph Reports supports `D30` and `D90`, but not `D60`.
- For 60 days, the collector downloads `D90` and filters daily rows to the requested window.
- Activity Explorer is limited to 30 days by default, even when the profile uses 60 or 90 days.
- Advanced Hunting receives a 30-, 60-, or 90-day `timespan`, subject to actual licensing and retention.
- Content/Data Explorer is a snapshot and may have reporting latency.

## Privacy and operations

- The directory summary does not persist users, UPNs, or individual license assignments.
- Activity Explorer aggregates records in memory and stores counts only.
- Policy and label names are retained because they are configuration evidence. Tenant-originated names are intentionally not translated in the English report.
- Protect `Collected Data` with restricted access and a defined retention period.
- Review the manifest before using the evidence for compliance or risk decisions.
