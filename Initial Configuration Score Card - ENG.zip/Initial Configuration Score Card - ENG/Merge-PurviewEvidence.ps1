#requires -Version 7.0

[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$TargetRunPath,
    [Parameter(Mandatory)][string]$DirectorySourceRunPath,
    [Parameter(Mandatory)][string]$ActivitySourceRunPath,
    [string]$ExportedDataPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-AtomicJson {
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)]$InputObject)
    $directory = Split-Path -Parent $Path
    $temporaryPath = Join-Path $directory ('.{0}.{1}.tmp' -f ([IO.Path]::GetFileName($Path)), ([guid]::NewGuid().ToString('N')))
    try {
        Set-Content -LiteralPath $temporaryPath -Value ($InputObject | ConvertTo-Json -Depth 100) -Encoding utf8NoBOM
        Move-Item -LiteralPath $temporaryPath -Destination $Path -Force
    }
    finally {
        if (Test-Path -LiteralPath $temporaryPath) { Remove-Item -LiteralPath $temporaryPath -Force }
    }
}

$target = (Resolve-Path -LiteralPath $TargetRunPath).Path
$directorySource = (Resolve-Path -LiteralPath $DirectorySourceRunPath).Path
$activitySource = (Resolve-Path -LiteralPath $ActivitySourceRunPath).Path
$targetManifestPath = Join-Path $target 'Run-Manifest.json'
$targetConfigurationPath = Join-Path $target 'Score-Configuration.json'

$manifest = Get-Content -LiteralPath $targetManifestPath -Raw | ConvertFrom-Json -Depth 100
$configuration = Get-Content -LiteralPath $targetConfigurationPath -Raw | ConvertFrom-Json -Depth 100 -AsHashtable
$directoryEnvelope = Get-Content -LiteralPath (Join-Path $directorySource 'DirectoryCoverage.json') -Raw | ConvertFrom-Json -Depth 100 -AsHashtable
$activityEnvelope = Get-Content -LiteralPath (Join-Path $activitySource 'ActivityExplorerAggregate.json') -Raw | ConvertFrom-Json -Depth 100 -AsHashtable
$directoryData = @($directoryEnvelope['data']) | Select-Object -First 1
if ($null -eq $directoryData) { throw 'Directory source does not contain data.' }
if ($activityEnvelope['evidenceStatus'] -ne 'Observed') { throw 'Activity source is not Observed.' }

$eligibleSkus = @($configuration['collection']['eligibleLicensing']['skuPartNumbers'])
$eligibleAssignments = 0
foreach ($assignment in @($directoryData['activeAssignmentsBySku'])) {
    if ($assignment['skuPartNumber'] -in $eligibleSkus) {
        $eligibleAssignments = [Math]::Max($eligibleAssignments, [int]$assignment['activeAssignedUsers'])
    }
}
$activeTargetUsers = [int]$directoryData['activeMemberUsers']
$eligibleRatio = if ($activeTargetUsers -gt 0) { [Math]::Round($eligibleAssignments / $activeTargetUsers, 6) } else { $null }
$directoryData['eligibleLicenseConfigurationPresent'] = ($eligibleSkus.Count -gt 0)
$directoryData['eligibleSkuPartNumbers'] = $eligibleSkus
$directoryData['eligibleServicePlanNames'] = @($configuration['collection']['eligibleLicensing']['servicePlanNames'])
$directoryData['activeTargetUsersWithEligibleSkuOrPlan'] = $eligibleAssignments
$directoryData['eligibleLicenseCoverageRatio'] = $eligibleRatio
$directoryData['eligibleLicenseEvidenceStatus'] = 'Imported'
$directoryData['eligibleLicenseMessage'] = "Recalculated from aggregate directory evidence in run $([IO.Path]::GetFileName($directorySource)); directory coverage is not time-window dependent."

$mergedDirectoryEnvelope = [ordered]@{
    schemaVersion = '1.0.0'
    collectorVersion = [string]$manifest.collectorVersion
    collectedAtUtc = [DateTime]::UtcNow.ToString('o')
    profile = [string]$manifest.profile
    lookbackDays = [int]$manifest.lookbackDays
    source = 'Microsoft Graph aggregate evidence imported from prior Basic run'
    command = 'Evidence merge and eligible-SKU recalculation'
    evidenceStatus = 'Imported'
    message = "Imported from $([IO.Path]::GetFileName($directorySource)); no user-level records persisted."
    recordCount = 1
    data = @($directoryData)
}
Write-AtomicJson -Path (Join-Path $target 'DirectoryCoverage.json') -InputObject $mergedDirectoryEnvelope
Write-AtomicJson -Path (Join-Path $target 'ActivityExplorerAggregate.json') -InputObject $activityEnvelope

$directoryItem = @($manifest.evidence | Where-Object name -eq 'DirectoryCoverage') | Select-Object -First 1
$directoryItem.status = 'Imported'
$directoryItem.recordCount = 1
$directoryItem.durationSeconds = 0
$directoryItem.message = "Imported and recalculated from run $([IO.Path]::GetFileName($directorySource))."

$activitySourceManifest = Get-Content -LiteralPath (Join-Path $activitySource 'Run-Manifest.json') -Raw | ConvertFrom-Json -Depth 100
$activitySourceItem = @($activitySourceManifest.evidence | Where-Object name -eq 'ActivityExplorerAggregate') | Select-Object -First 1
$activityItem = @($manifest.evidence | Where-Object name -eq 'ActivityExplorerAggregate') | Select-Object -First 1
$activityItem.status = $activitySourceItem.status
$activityItem.recordCount = $activitySourceItem.recordCount
$activityItem.durationSeconds = $activitySourceItem.durationSeconds
$activityItem.message = "Observed in focused retry run $([IO.Path]::GetFileName($activitySource))."

$manifest.summary.observed = @($manifest.evidence | Where-Object status -eq 'Observed').Count
$manifest.summary.notObserved = @($manifest.evidence | Where-Object status -eq 'NotObserved').Count
$manifest.summary.unavailable = @($manifest.evidence | Where-Object status -eq 'Unavailable').Count
$manifest.summary.notCollected = @($manifest.evidence | Where-Object status -eq 'NotCollected').Count
$manifest.summary | Add-Member -NotePropertyName imported -NotePropertyValue @($manifest.evidence | Where-Object status -eq 'Imported').Count -Force
$manifest | Add-Member -NotePropertyName enrichment -NotePropertyValue ([pscustomobject]@{
    mergedAtUtc = [DateTime]::UtcNow.ToString('o')
    directorySourceRun = [IO.Path]::GetFileName($directorySource)
    activitySourceRun = [IO.Path]::GetFileName($activitySource)
    method = 'Evidence-level merge; original source run IDs retained.'
}) -Force
$manifest.messages = @($manifest.messages) + @([pscustomobject]@{
    timestampUtc = [DateTime]::UtcNow.ToString('o')
    level = 'Information'
    message = 'Directory coverage and Activity Explorer evidence were enriched from traceable same-tenant runs.'
})
Write-AtomicJson -Path $targetManifestPath -InputObject $manifest

if ([string]::IsNullOrWhiteSpace($ExportedDataPath)) { $ExportedDataPath = Join-Path (Split-Path -Parent $target) 'Exported Data' }
$reportGenerator = Join-Path $PSScriptRoot 'Export-PurviewHtmlReport.ps1'
$reportPath = @(& $reportGenerator -RunPath $target -ExportedDataPath $ExportedDataPath) | Select-Object -Last 1
Write-Host "Evidence merged and report regenerated: $reportPath"
Write-Output $reportPath
